from django.contrib import admin
from baby.models import *

admin.site.register(baby)
admin.site.register(baby_barcode)
admin.site.register(baby_breastfeeding)
admin.site.register(baby_chat)
admin.site.register(baby_defecation)
admin.site.register(baby_dessertfruit)
admin.site.register(baby_diaper)
admin.site.register(baby_grocery)
admin.site.register(baby_picture)
admin.site.register(baby_relatives)

