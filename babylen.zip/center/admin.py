from django.contrib import admin
from center.models import *

admin.site.register(center_picture)
admin.site.register(center_visit)
