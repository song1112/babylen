from django.contrib import admin
from baby_user.models import user, user_normal, user_daycarecenter, user_bonne 

admin.site.register(user)
admin.site.register(user_normal)
admin.site.register(user_daycarecenter)
admin.site.register(user_bonne)


