from django.contrib import admin
from produce.models import *

admin.site.register(produce_type)
admin.site.register(produce)
admin.site.register(produce_trade)
